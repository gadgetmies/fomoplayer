// Local demo (demo-test workflow): runs against a backend in the same runner.
// The top bar search across navigation: its icon, Settings keeping the search with a way back (also tapped on a
// phone), back showing the search at once, and Discover and Notifications emptying the bar. Tracks are seeded
// through the API, the same in both demos.
const { test } = require('cascade-test')
const { getSharedContext, getMobileContext, teardownSharedContext } = require('../lib/setup')
const { seedOnePlayerTracksViaApi } = require('../lib/one-player-seed')
const {
  openDiscover,
  assertSearchIconShownAndCentred,
  assertSettingsKeepsSearchWithWayBack,
  assertBackShowsSearchAtOnce,
  assertShowResultsTapOnMobile,
  assertOtherListClearsSearch,
  assertNotificationsClearsSearch,
} = require('../lib/search-bar-navigation-steps')

test({
  teardown: teardownSharedContext,
  setup: async () => {
    const { page } = await getSharedContext()
    await seedOnePlayerTracksViaApi(page)
    await openDiscover(page)
    const { page: mobilePage } = await getMobileContext()
    return { page, mobilePage, timeout: 60000 }
  },

  'the search icon shows, centred, with and without focus': assertSearchIconShownAndCentred,
  'Settings keeps the search and offers a way back to its results': assertSettingsKeepsSearchWithWayBack,
  'going back to a search shows its terms before the results arrive': assertBackShowsSearchAtOnce,
  'Discover empties the search bar': assertOtherListClearsSearch,
  'Notifications empties the search bar': assertNotificationsClearsSearch,
  'on a phone, tapping "Show results" opens the results again': assertShowResultsTapOnMobile,
})
