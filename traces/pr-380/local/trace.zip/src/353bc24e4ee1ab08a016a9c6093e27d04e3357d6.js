import * as R from 'ramda';
import * as fs from 'fs';
import * as path from 'path';
import 'colors';
import { createReporter, detectCI, addCIAnnotations } from './reporters.js';
import { getDisplayTestFile } from './path-utils.js';
const DefaultAssertionTimeout = 5000;
const DefaultGroupTimeout = 10000;
const noop = () => null;
const passThrough = (value) => value;
const escapeRegExp = (value) => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const normalizeFilePath = (filePath) => {
    if (filePath.startsWith('file://')) {
        return decodeURIComponent(filePath.replace('file://', ''));
    }
    return filePath;
};
const findTestImplementationLine = (filePath, testPath) => {
    try {
        const source = fs.readFileSync(normalizeFilePath(filePath), 'utf8');
        const lines = source.split('\n');
        let searchFrom = 0;
        let matchedLine;
        for (const segment of testPath) {
            const escapedSegment = escapeRegExp(segment);
            const quotedPattern = new RegExp(`['"\`]${escapedSegment}['"\`]\\s*:`);
            const barePattern = new RegExp(`\\b${escapedSegment}\\b\\s*:`);
            let found = -1;
            for (let i = searchFrom; i < lines.length; i += 1) {
                const line = lines[i];
                if (quotedPattern.test(line) || barePattern.test(line)) {
                    found = i;
                    break;
                }
            }
            if (found === -1) {
                break;
            }
            matchedLine = found + 1;
            searchFrom = found + 1;
        }
        return matchedLine;
    }
    catch {
        return undefined;
    }
};
const timeout = (timeoutMs, label = 'Test') => {
    let id;
    const promise = new Promise((_, reject) => {
        id = setTimeout(() => {
            reject(new Error(`${label} timed out after ${timeoutMs}ms`));
        }, timeoutMs);
    });
    return {
        promise,
        cancel: () => clearTimeout(id),
    };
};
function getCallerFile() {
    const originalFunc = Error.prepareStackTrace;
    let callerfile;
    try {
        const err = new Error();
        let currentfile;
        Error.prepareStackTrace = function (err, stack) {
            return stack;
        };
        // When prepareStackTrace is set, err.stack becomes NodeJS.CallSite[] instead of string
        const stack = err.stack;
        currentfile = stack?.shift()?.getFileName() || undefined;
        while (stack && stack.length) {
            callerfile = stack.shift()?.getFileName() || undefined;
            if (currentfile !== callerfile)
                break;
        }
    }
    catch (e) {
        // Ignore errors
    }
    Error.prepareStackTrace = originalFunc;
    return callerfile;
}
const test = async (suite, config = {}) => {
    // Read configuration from environment variables if not provided
    const finalConfig = {
        reporter: config.reporter || process.env.CASCADE_TEST_REPORTER || 'console',
        outputFile: config.outputFile || process.env.CASCADE_TEST_OUTPUT || undefined,
        ci: config.ci || process.env.CASCADE_TEST_CI || undefined
    };
    // Initialize reporter and CI detection
    const ci = finalConfig.ci || detectCI();
    const reporter = createReporter(finalConfig.reporter || 'console', finalConfig.outputFile);
    const casePattern = config.testPattern || process.env.CASCADE_TEST_CASE_REGEX;
    const caseRegex = casePattern ? new RegExp(casePattern) : undefined;
    const testResults = [];
    const matchesCaseFilter = (testPath) => {
        if (!caseRegex) {
            return true;
        }
        caseRegex.lastIndex = 0;
        const scopePath = testPath.slice(1);
        const fullPath = scopePath.join(' > ');
        const leafName = scopePath.at(-1) || '';
        return caseRegex.test(fullPath) || caseRegex.test(leafName);
    };
    const suiteHasMatchingTests = (suiteNode, currentPath) => {
        const { setup, teardown, skip, timeout, ...entries } = suiteNode;
        for (const key of Object.keys(entries)) {
            const value = entries[key];
            const nextPath = [...currentPath, key];
            if (R.is(Function, value)) {
                if (matchesCaseFilter(nextPath)) {
                    return true;
                }
                continue;
            }
            if (suiteHasMatchingTests(value, nextPath)) {
                return true;
            }
        }
        return false;
    };
    const extractFnPaths = (node) => Object.keys(node).reduce((acc, key) => {
        const value = node[key];
        if (R.is(Function, value)) {
            return [...acc, [key, value]];
        }
        else if (typeof value === 'object') {
            const nestedPaths = extractFnPaths(value);
            return [...acc, ...nestedPaths.map(path => [key, path])];
        }
        return acc;
    }, []);
    const collectDescriptions = (node) => Object.keys(node).reduce((acc, key) => {
        const value = node[key];
        if (R.allPass([R.is(Object), R.complement(R.is(Function))])(value)) {
            return [...acc, [key, collectDescriptions(value)]];
        }
        else {
            return [...acc, [key]];
        }
    }, []);
    const printFail = (error, style = 'console') => style === 'console' ? `${'FAIL'.red}: ${error}` : `<span class="fail">FAIL: ${error}</span>`;
    const printPass = (style = 'console') => style === 'console' ? 'PASS'.green : '<span class="pass">PASS</span>';
    const printSkip = (style = 'console') => style === 'console' ? 'SKIP'.yellow : '<span class="pass">SKIP</span>';
    const printName = (name, style = 'console') => style === 'console' ? `• ${name.cyan}:\n` : `<span class="test">${name}:</span>\n`;
    const printChildren = (children, style = 'console') => style === 'console' ? children.join('\n') : `<ul>\n${children.map((c) => `<li>${c}</li>\n`).join('')}\n</ul>\n`;
    const getIndentString = (indent) => ' '.repeat(indent);
    const isTestGroup = (content) => {
        return Array.isArray(content);
    };
    const isTestResult = (content) => {
        return !Array.isArray(content) && 'error' in content;
    };
    const isTestStructure = (description) => {
        return description.length === 2;
    };
    const collectFailedTests = (structure, currentPath = [], sourceFile) => {
        const [name, content] = structure;
        const fullPath = [...currentPath, name];
        const failedTests = [];
        if (isTestGroup(content)) {
            for (const child of content) {
                if (isTestStructure(child)) {
                    failedTests.push(...collectFailedTests(child, fullPath, sourceFile));
                }
                // TODO: In what case would the content be a list of strings and contain only one element?
                // Skip [string] only descriptions as they don't contain test results
            }
        }
        else if (isTestResult(content) && content.error) {
            const testHierarchy = fullPath.slice(1);
            const resolvedSourceFile = sourceFile ? normalizeFilePath(sourceFile) : undefined;
            const line = resolvedSourceFile ? findTestImplementationLine(resolvedSourceFile, testHierarchy) : undefined;
            const relativeFile = resolvedSourceFile ? path.relative(process.cwd(), resolvedSourceFile) : undefined;
            // This is a failed test
            failedTests.push({
                path: fullPath,
                error: content.error,
                file: relativeFile,
                line
            });
        }
        return failedTests;
    };
    const printStructure = (node, style = 'console', indent = 2) => {
        const indentString = getIndentString(indent);
        return `\
${printName(node[0], style)}${R.is(Array, node[1])
            ? printChildren(node[1].map((n) => indentString.concat(printStructure(n, style, indent + 2))), style)
            : node[1].error
                ? indentString.concat(printFail(node[1].error, style))
                : node[1].skipped
                    ? indentString.concat(printSkip(style))
                    : indentString.concat(printPass(style))}`;
    };
    const run = async (suite, { skippingReason, indent = 0, parentContext, currentPath = [] } = {}) => {
        try {
            const { setup = passThrough, teardown = noop, skip = noop, ...rest } = suite;
            if (caseRegex && !suiteHasMatchingTests(rest, currentPath)) {
                return [];
            }
            // Only evaluate this suite's skip if no ancestor has already marked it as skipped
            if (!skippingReason && skip !== noop) {
                const skipResult = skip();
                if (skipResult && typeof skipResult === 'object' && 'reason' in skipResult && 'until' in skipResult) {
                    const skipConfig = skipResult;
                    const skipDate = new Date(skipConfig.until);
                    const now = new Date();
                    if (skipDate > now) {
                        skippingReason = skipConfig.reason;
                    }
                    else {
                        const skipDateString = typeof skipConfig.until === 'string' ? skipConfig.until : skipDate.toISOString();
                        const error = `Test skip expired on ${skipDateString}. Reason: ${skipConfig.reason}`;
                        testResults.push({
                            name: currentPath.at(-1),
                            path: currentPath,
                            status: 'failed',
                            error
                        });
                        return [[
                                'skip-expired',
                                {
                                    skipped: false,
                                    error,
                                }
                            ]];
                    }
                }
            }
            let setupResult;
            if (skippingReason === undefined) {
                try {
                    setupResult = await setup(parentContext);
                }
                catch (e) {
                    console.error(e);
                    return [[
                            'setup-error',
                            {
                                skipped: false,
                                error: `Setup failed with: '${e.toString()}'`,
                            }
                        ]];
                }
            }
            const result = [];
            for (const key of Object.keys(rest)) {
                console.log(`${getIndentString(indent)}• ${key} ${skippingReason ? `SKIPPING (reason: ${skippingReason})` : ''}`.blue);
                const restElement = rest[key];
                let singleResult;
                const timeouts = [];
                const testStartTime = Date.now();
                const testPath = [...currentPath, key];
                try {
                    if (R.is(Function, restElement)) {
                        if (caseRegex && !matchesCaseFilter(testPath)) {
                            continue;
                        }
                        if (skippingReason) {
                            singleResult = {
                                skipped: skippingReason
                            };
                            testResults.push({
                                name: key,
                                path: testPath,
                                status: 'skipped'
                            });
                        }
                        else {
                            const assertionTimeout = timeout(setupResult?.timeout || DefaultAssertionTimeout, 'Test');
                            timeouts.push(assertionTimeout);
                            const { cancel, promise: timeoutPromise } = assertionTimeout;
                            const res = await Promise.race([restElement(setupResult), timeoutPromise]);
                            const testDuration = Date.now() - testStartTime;
                            const testError = res !== undefined ? res : undefined;
                            singleResult = {
                                skipped: false,
                                error: testError,
                            };
                            testResults.push({
                                name: key,
                                path: testPath,
                                status: testError ? 'failed' : 'passed',
                                error: testError ? testError : undefined,
                                duration: testDuration
                            });
                            cancel();
                        }
                    }
                    else {
                        if (caseRegex && !suiteHasMatchingTests(restElement, testPath)) {
                            continue;
                        }
                        const groupTimeout = timeout(setupResult?.timeout || DefaultGroupTimeout, 'Suite');
                        timeouts.push(groupTimeout);
                        const { cancel, promise: timeoutPromise } = groupTimeout;
                        const nestedResults = await Promise.race([
                            run(restElement, {
                                skippingReason,
                                indent: indent + 2,
                                parentContext: setupResult,
                                currentPath: [...currentPath, key]
                            }),
                            timeoutPromise,
                        ]);
                        singleResult = nestedResults;
                        cancel();
                    }
                }
                catch (e) {
                    console.error(`Test '${key}' failed:`.red, e);
                    const error = e.message;
                    singleResult = { skipped: false, error };
                    testResults.push({
                        name: key,
                        path: testPath,
                        status: 'failed',
                        error,
                        duration: Date.now() - testStartTime
                    });
                    timeouts.forEach((t) => t.cancel());
                }
                result.push([key, singleResult]);
            }
            if (!skippingReason) {
                try {
                    await teardown(setupResult);
                }
                catch (e) {
                    console.error(e);
                    throw new Error(`Teardown failed with: '${e.toString()}'`);
                }
            }
            return result;
        }
        catch (e) {
            console.error(e);
            throw new Error(`Test group execution failed!: '${e.toString()}'`);
        }
    };
    try {
        const testFile = getCallerFile();
        const displayTestFile = getDisplayTestFile(testFile || 'unknown', process.env.CASCADE_TEST_BASE_PATH || process.cwd());
        console.log('-'.repeat(60));
        console.log('Running test suite:', displayTestFile);
        console.log('-'.repeat(60), '\n');
        const result = [displayTestFile, await run(suite, { currentPath: [testFile || 'unknown'] })];
        console.log('\nResults:\n', printStructure(result));
        const failedTests = collectFailedTests(result, [], testFile);
        const exitCode = failedTests.length === 0 ? 0 : 1;
        // Use reporter to generate output
        reporter.onTestSuiteComplete(testResults, displayTestFile);
        const reporterOutput = reporter.generateOutput();
        // If no output file is configured and a structured reporter is used,
        // print the reporter output to stdout so CI parsers can pick it up
        if ((finalConfig.reporter && finalConfig.reporter !== 'console') && !finalConfig.outputFile) {
            console.log(reporterOutput);
        }
        console.log(`\nTest suite (${displayTestFile}) finished ${exitCode === 0 ? 'successfully'.green : `with ${failedTests.length} error(s)`.red}`);
        addCIAnnotations(failedTests, ci);
        // Write comprehensive test results to a temporary file for CLI consumption
        const tempFile = path.join(process.cwd(), '.cascade-test-results.json');
        try {
            const testSummary = {
                total: testResults.length,
                passed: testResults.filter(r => r.status === 'passed').length,
                failed: testResults.filter(r => r.status === 'failed').length,
                skipped: testResults.filter(r => r.status === 'skipped').length,
                failedTests: failedTests,
                results: testResults,
                testFile: displayTestFile
            };
            fs.writeFileSync(tempFile, JSON.stringify(testSummary, null, 2));
        }
        catch (e) {
            // Ignore file write errors
        }
        if (failedTests.length > 0) {
            failedTests.forEach((failedTest) => {
                const pathString = failedTest.path.slice(1).join(' → ');
                console.log(`\n• ${pathString}`.red);
                if (failedTest.file) {
                    const location = failedTest.line ? `${failedTest.file}:${failedTest.line}` : failedTest.file;
                    console.log(`  Location: ${location}`.cyan);
                }
                console.log(`  Reason: ${failedTest.error}`.yellow);
            });
        }
        console.log('\n');
        // Don't exit immediately - let the process exit naturally
        // This allows the parent process to capture the output
        setTimeout(() => process.exit(exitCode), 0);
    }
    catch (e) {
        console.error(`Test suite execution failed: ${e.toString()}`.red);
        console.error(e);
    }
};
export default test;
//# sourceMappingURL=test.js.map